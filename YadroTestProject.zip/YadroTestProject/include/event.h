#pragma once
#ifndef EVENT_H
#define EVENT_H
#include "myTime.h"

class event
{
private:
    std::string description;
    int ID, compID;
    myTime time;

public:
    event();
    event(std::string time, int ID, std::string description);
    event(std::string time, int ID, std::string description, int compID);
    int getID() const;
    int getCompID() const;
    std::string getDesc()const;
    myTime getTime() const;
};

event::event()
{
    this->time = myTime();
    this->ID = 0;
    this->description = "nothing";
    this->compID = 0;
}

event::event(std::string time, int ID, std::string description)
{
    this->time = myTime(time);
    this->ID = ID;
    this->description = description;
    this->compID = 0;
}

event::event(std::string time, int ID, std::string description, int compID)
{
    this->time = myTime(time);
    this->ID = ID;
    this->description = description;
    this->compID = compID;
}

int event::getID() const {return this->ID;}
int event::getCompID() const {return this->compID;}
std::string event::getDesc()const {return this->description;}
myTime event::getTime() const {return this->time;}

std::ostream& operator << (std::ostream &os, const event &e)
{
    if(e.getID() == 2) return os << e.getTime() <<' '<< e.getID() << ' ' << e.getDesc() << ' ' << e.getCompID();
    return os << e.getTime()<<' '<< e.getID() << ' ' << e.getDesc();
}
#endif