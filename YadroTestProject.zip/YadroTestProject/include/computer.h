#pragma once
#ifndef COMPUTER_H
#define COMPUTER_H

#include "myTime.h"

class computer
{
private:
    bool status;
    int totalHours;
    myTime startTime;
    myTime totalTime;

public:
    computer();

    void clientSit(myTime start);
    void clientUp(myTime time);
    
    bool getStatus();
    int getTotalHours();
    myTime getTotalTime();
};

computer:: computer()
{
    this->status = false;
    this->totalHours = 0;
    this->startTime = myTime();
    this->totalTime = myTime();
}

void computer::clientSit(myTime start)
{
    this->status = true;
    this->startTime = start;
}

void computer::clientUp(myTime time)
{
    this->status = false;
    this->totalTime += time.difference(startTime);
    totalHours += time.getWorkHrs(startTime);
}

bool computer::getStatus() {return status;}
int computer::getTotalHours() {return totalHours;}
myTime computer::getTotalTime() {return totalTime;}
#endif