#pragma once
#ifndef MYTIME_H
#define MYTIME_H
#include <iostream>

class myTime
{
private:
    int hours, minutes;
public:
    myTime();
    myTime(std::string input);

    int getHours() const;
    int getMinutes() const;

    void setHours(int hours);
    void setMinutes(int minutes);
    void setTime(std::string time);

    bool isItvalid(myTime m);

    bool operator > (const myTime & m) const;
    bool operator < (const myTime & m) const;
    myTime& operator += (const myTime & t);

    int getWorkHrs(const myTime &start);
    myTime difference(const myTime &start);
};

myTime::myTime()
{
    this->hours = 0;
    this->minutes = 0;
}
myTime::myTime(std::string input)
{
    int hours = -('0'-input[0])*10 + -('0'-input[1]);
    int minutes = -('0'-input[3])*10 + -('0'-input[4]);
        
    if(hours > 0 && hours < 24 && minutes > 0 && minutes < 60)
    {
        this->hours = hours;
        this->minutes = minutes;
    }
    else
    {
        this->hours = 0;
        this->minutes = 0;
    }
}

int myTime::getHours() const { return hours; }

int myTime::getMinutes() const { return minutes; }

void myTime::setHours(int hours)
{
    if(hours >= 0 && hours < 24)
        this->hours = hours;
    else 
        this->hours = 0;
}

void myTime::setMinutes(int minutes)
{
    if(minutes > 0 && minutes < 60)
        this->minutes = minutes;
    else 
        this->minutes = 0;
}

void myTime::setTime(std::string time)
{
    int hours = -('0'-time[0])*10 + -('0'-time[1]);
    int minutes = -('0'-time[3])*10 + -('0'-time[4]);
        
    if(hours >= 0 && hours < 24 && minutes >= 0 && minutes < 60)
    {
        this->hours = hours;
        this->minutes = minutes;
    }
    else
    {
        this->hours = 0;
        this->minutes = 0;
    }
}

bool myTime::isItvalid(myTime m)
{
    int diff1 = this->getHours()-m.getHours();
    int diff2 = this->getMinutes()-m.getMinutes();

    if(diff1 > 0) return true;
    if(diff1 == 0 && diff2 >= 0) return true;

    return false;
}

bool myTime::operator > (const myTime & m) const
{
    if(hours == m.getHours())
        return minutes > m.getMinutes();
    return hours > m.hours;
}

bool myTime::operator < (const myTime & m) const
{
    if(hours == m.getHours())
        return minutes < m.getMinutes();
    return hours < m.hours;
}

myTime& myTime::operator += (const myTime & t)
{
    this->hours = (this->hours+t.getHours() + (this->minutes+t.getMinutes()) / 60) % 24;
    this->minutes = (this->minutes+t.getMinutes()) % 60;
    return *this;
}

int myTime::getWorkHrs(const myTime &start)
{
    if(*this < start) return 0;

    int diffHrs = this->getHours() - start.getHours();
    int diffMins = this->getMinutes() - start.getMinutes();

    if(diffMins > 0) return diffHrs + 1;
    else if(diffHrs) return diffHrs;
    else return 1;
}

myTime myTime::difference(const myTime &start)
{
    myTime ans = myTime();
    if(*this < start) return ans;

    ans.setHours(this->getHours()-start.getHours());
    if(start.getMinutes() <= this->getMinutes())
        ans.setMinutes(this->getMinutes()-start.getMinutes());
    else
    {
        ans.setHours(ans.getHours()-1);
        ans.setMinutes(60-start.getMinutes() + this->getMinutes());
    }

    return ans;
}

std::ostream& operator << (std::ostream &os, const myTime &m)
{
    if(m.getHours() < 10 && m.getMinutes() < 10)
        return os << '0' << m.getHours() << ':' << '0' << m.getMinutes();
    else if(m.getHours() < 10 && m.getMinutes() >= 10)
        return os << '0' << m.getHours() << ':' << m.getMinutes();
    else if(m.getHours() >= 10 && m.getMinutes() < 10)
        return os << m.getHours() << ':' << '0' << m.getMinutes();
    else
        return os << m.getHours() << ':' << m.getMinutes();
}

std::istream& operator >> (std::istream& in, myTime& m)
{
    std::string input;
    in >> input;
    
    int hours = -('0'-input[0])*10 + -('0'-input[1]);
    int minutes = -('0'-input[3])*10 + -('0'-input[4]);

    m.setHours(hours); m.setMinutes(minutes);
    return in;
}
#endif